import React from "react";

const Disk = () => {
  return (
    <div>
      <div className="bg-slate-400 w-2 h-2 mt-[10px]"></div>{" "}
    </div>
  );
};

export default Disk;
